
.. automodule:: GSimpleGA
   :members:

