

.. automodule:: FunctionSlot
   :members:
